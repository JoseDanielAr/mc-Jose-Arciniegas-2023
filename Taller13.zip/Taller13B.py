import numpy as np 
Ma1=[]
Ma2=[]
Ar=[]
#Matriz 1
f=int(input("Ingrese el numero de filas de la matriz 1"))
c=int(input("ingrese el numero de columnas de la matriz 1"))

for i in range (0,f):
 for j in range(0, c):
     n=float(input("ingresa la valor " + str(j+1) +"de la linea " + str(i+1) + ": "))
     Ar.append(n)
 Ma1.append(Ar)
 Ar=[]
print(Ma1)


#Matriz 2:
f=int(input("Ingrese el numero de filas de la matriz 2"))
c=int(input("ingrese el numero de columnas de la matriz 2"))
for i in range (0,f):
 for j in range(0, c):
     n=float(input("ingresa la valor " + str(j+1) +"de la linea " + str(i+1) +": " ))
     Ar.append(n)
 Ma2.append(Ar)
 Ar=[]
print(Ma2)

#Operaciones
print("\nOPERACIONES:\n A)3*A")
print(np.multiply(3, Ma1))

print("\nB)4B")
print(np.multiply(4, Ma2))

print("\nC)A+B")
if len(Ma1)==len(Ma2):
    if len(Ma1[0])==len(Ma2[0]):
     print(np.add(Ma1,Ma2))
    else:
     print("No es posible")
else:
    print("No es posible")

print("\nD)BXA:")
if len(Ma1[0])==len(Ma2):
  print(np.matmul(Ma1, Ma2))
else:
  print("No es posible")
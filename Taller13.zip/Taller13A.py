import numpy as np

Ar1=[]
Ar2=[]
#Matriz1
t=int(input("Ingrese el tamaño de los vectores: "))


for i in range(0,t):
 n=float(input("ingrese el numero para la posición " + str(i) +" de la matriz 1: "))
 Ar1.append(n)
 
for i in range(0,t):
 n=float(input("ingrese el numero para la posición " + str(i) +" de la matriz 2: "))
 Ar2.append(n)
 
print(np.dot(Ar1,Ar2))